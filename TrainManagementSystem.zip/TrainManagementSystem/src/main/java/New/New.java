package New;
class New{
public static void main(String ar[]) {
	int a=Integer.parseInt(a[0]);
}
}